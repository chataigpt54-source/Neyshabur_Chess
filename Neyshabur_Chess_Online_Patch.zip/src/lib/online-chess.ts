import 'server-only';
import { createHash, randomBytes } from 'node:crypto';
import { cookies } from 'next/headers';
import { supabaseAdmin } from '@/lib/supabase-admin';

export const ONLINE_COOKIE_PREFIX = 'neyshabur_online_';
export const INITIAL_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

export function hashToken(token: string) {
  return createHash('sha256').update(token).digest('hex');
}
export function newToken() {
  return randomBytes(32).toString('base64url');
}
export async function currentOnlinePlayer(tournamentId: string) {
  const store = await cookies();
  const token = store.get(ONLINE_COOKIE_PREFIX + tournamentId)?.value;
  if (!token) return null;
  const { data } = await supabaseAdmin
    .from('online_players')
    .select('id,tournament_id,display_name,points,bye_count')
    .eq('tournament_id', tournamentId)
    .eq('token_hash', hashToken(token))
    .maybeSingle();
  return data;
}
export function safeName(value: unknown) {
  if (typeof value !== 'string') return '';
  return value.trim().replace(/\s+/g, ' ').slice(0, 32);
}
export async function isFinishedTimeout(game: any) {
  if (game.status !== 'playing' || !game.last_tick_at) return game;
  const elapsed = Math.max(0, Date.now() - new Date(game.last_tick_at).getTime());
  const field = game.active_color === 'w' ? 'white_ms' : 'black_ms';
  const remaining = Math.max(0, Number(game[field]) - elapsed);
  if (remaining > 0) return { ...game, [field]: remaining };
  const result = game.active_color === 'w' ? '0-1' : '1-0';
  const { data } = await supabaseAdmin.from('online_games').update({
    [field]: 0, status: 'finished', result, finish_reason: 'timeout',
    finished_at: new Date().toISOString(), last_tick_at: null, draw_offer_by: null,
  }).eq('id', game.id).eq('status', 'playing').select('*').maybeSingle();
  if (data) await applyGamePoints(data);
  return data || { ...game, [field]: 0, status: 'finished', result };
}
export async function applyGamePoints(game: any) {
  if (!game || !game.result) return;
  const { data: existing } = await supabaseAdmin.from('online_games')
    .select('points_applied').eq('id', game.id).maybeSingle();
  // Older schemas may not have this optional guard column; result updates are only done once per game.
  if (existing?.points_applied) return;
  const white = game.white_player_id;
  const black = game.black_player_id;
  if (game.result === '1-0' && white) {
    const { data: p } = await supabaseAdmin.from('online_players').select('points').eq('id', white).maybeSingle();
    await supabaseAdmin.from('online_players').update({ points: Number(p?.points || 0) + 1 }).eq('id', white);
  } else if (game.result === '0-1' && black) {
    const { data: p } = await supabaseAdmin.from('online_players').select('points').eq('id', black).maybeSingle();
    await supabaseAdmin.from('online_players').update({ points: Number(p?.points || 0) + 1 }).eq('id', black);
  } else if (game.result === '1/2-1/2') {
    for (const id of [white, black].filter(Boolean)) {
      const { data: p } = await supabaseAdmin.from('online_players').select('points').eq('id', id).maybeSingle();
      await supabaseAdmin.from('online_players').update({ points: Number(p?.points || 0) + 0.5 }).eq('id', id);
    }
  }
  await supabaseAdmin.from('online_games').update({ points_applied: true }).eq('id', game.id);
}
export async function createRound(tournamentId: string) {
  const { data: tournament, error: tournamentError } = await supabaseAdmin
    .from('online_tournaments').select('*').eq('id', tournamentId).single();
  if (tournamentError || !tournament) throw new Error('مسابقه پیدا نشد.');
  if (tournament.status !== 'running') throw new Error('مسابقه هنوز شروع نشده است.');
  const { data: games } = await supabaseAdmin.from('online_games')
    .select('round_number,status').eq('tournament_id', tournamentId)
    .order('round_number', { ascending: false }).limit(10000);
  const currentRound = Math.max(0, ...(games || []).map((g: any) => Number(g.round_number)));
  if ((games || []).some((g: any) => Number(g.round_number) === currentRound && g.status !== 'finished')) {
    throw new Error('ابتدا تمام بازی‌های دور جاری باید تمام شوند.');
  }
  if (tournament.format === 'swiss' && currentRound >= Number(tournament.rounds)) {
    await supabaseAdmin.from('online_tournaments').update({ status: 'finished' }).eq('id', tournamentId);
    throw new Error('تمام دورهای سوئیسی برگزار شده است.');
  }
  const round = currentRound + 1;
  const { data: players, error } = await supabaseAdmin.from('online_players')
    .select('id,points,bye_count,display_name').eq('tournament_id', tournamentId)
    .order('points', { ascending: false }).order('joined_at', { ascending: true });
  if (error) throw new Error(error.message);
  if (!players || players.length < 2) throw new Error('برای شروع حداقل دو بازیکن لازم است.');
  const shuffled = [...players].sort((a: any,b: any) => {
    if (Number(b.points) !== Number(a.points)) return Number(b.points)-Number(a.points);
    return Math.random() - 0.5;
  });
  let bye: any = null;
  if (shuffled.length % 2) {
    bye = shuffled.pop();
    await supabaseAdmin.from('online_players').update({ points: Number(bye.points || 0) + 1, bye_count: Number(bye.bye_count || 0) + 1 }).eq('id', bye.id);
  }
  // Greedy pairing: avoid previous opponents whenever a swap can do so.
  const { data: previous } = await supabaseAdmin.from('online_games')
    .select('white_player_id,black_player_id').eq('tournament_id', tournamentId);
  const met = new Set((previous || []).map((g: any) => [g.white_player_id,g.black_player_id].filter(Boolean).sort().join(':')));
  const pairings: any[] = [];
  while (shuffled.length >= 2) {
    const a = shuffled.shift();
    let idx = shuffled.findIndex((b: any) => !met.has([a.id,b.id].sort().join(':')));
    if (idx < 0) idx = 0;
    const b = shuffled.splice(idx,1)[0];
    const whiteFirst = Math.random() < 0.5;
    pairings.push({ tournament_id:tournamentId, round_number:round, white_player_id:whiteFirst?a.id:b.id, black_player_id:whiteFirst?b.id:a.id,
      status:'playing', fen:INITIAL_FEN, pgn:'', moves:[], white_ms:(Number(tournament.time_minutes)*60+Number(tournament.time_seconds))*1000,
      black_ms:(Number(tournament.time_minutes)*60+Number(tournament.time_seconds))*1000, active_color:'w',
      last_tick_at:new Date().toISOString(), started_at:new Date().toISOString() });
  }
  const { error: insertError } = await supabaseAdmin.from('online_games').insert(pairings);
  if (insertError) throw new Error(insertError.message);
  return { round, pairings: pairings.length, bye: bye?.display_name || null };
}

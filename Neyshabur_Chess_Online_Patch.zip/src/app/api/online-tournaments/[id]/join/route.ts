import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { supabaseAdmin } from '@/lib/supabase-admin';
import { hashToken, newToken, safeName, ONLINE_COOKIE_PREFIX } from '@/lib/online-chess';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({error:'اطلاعات نامعتبر است.'},{status:400}); }
  const name = safeName(body?.display_name);
  if (name.length < 2) return NextResponse.json({error:'نام باید حداقل دو حرف داشته باشد.'},{status:400});
  const {data:t,error:te} = await supabaseAdmin.from('online_tournaments').select('*').eq('id',params.id).maybeSingle();
  if (te || !t) return NextResponse.json({error:'مسابقه پیدا نشد.'},{status:404});
  if (!['scheduled','registration'].includes(t.status) || new Date(t.start_at).getTime() < Date.now())
    return NextResponse.json({error:'ثبت‌نام این مسابقه بسته است.'},{status:409});
  const {count: playerCount} = await supabaseAdmin.from('online_players').select('id',{count:'exact',head:true}).eq('tournament_id',params.id);
  if ((playerCount ?? 0) >= t.capacity) return NextResponse.json({error:'ظرفیت مسابقه تکمیل شده است.'},{status:409});
  const token = newToken();
  const {data: player,error} = await supabaseAdmin.from('online_players').insert({
    tournament_id:params.id, display_name:name, token_hash:hashToken(token)
  }).select('id,display_name,points').single();
  if (error) {
    if (error.code === '23505') return NextResponse.json({error:'این نام قبلاً در مسابقه ثبت شده است.'},{status:409});
    return NextResponse.json({error:'ثبت‌نام انجام نشد.'},{status:500});
  }
  const jar = await cookies();
  jar.set(ONLINE_COOKIE_PREFIX+params.id, token, {httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',path:'/',maxAge:60*60*24*14});
  return NextResponse.json({player});
}

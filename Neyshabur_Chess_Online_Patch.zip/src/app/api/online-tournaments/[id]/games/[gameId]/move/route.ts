import { NextRequest, NextResponse } from 'next/server';
import { Chess } from 'chess.js';
import { supabaseAdmin } from '@/lib/supabase-admin';
import { currentOnlinePlayer, isFinishedTimeout, applyGamePoints } from '@/lib/online-chess';

export async function POST(req:NextRequest,{params}:{params:{id:string;gameId:string}}) {
  const me = await currentOnlinePlayer(params.id);
  if (!me) return NextResponse.json({error:'ابتدا با نام خود وارد مسابقه شو.'},{status:401});
  let body:any; try { body=await req.json(); } catch { return NextResponse.json({error:'حرکت نامعتبر است.'},{status:400}); }
  const {data:raw} = await supabaseAdmin.from('online_games').select('*').eq('id',params.gameId).eq('tournament_id',params.id).maybeSingle();
  if (!raw) return NextResponse.json({error:'بازی پیدا نشد.'},{status:404});
  const g:any = await isFinishedTimeout(raw);
  if (g.status !== 'playing') return NextResponse.json({error:'این بازی فعال نیست.'},{status:409});
  const color = g.white_player_id===me.id?'w':g.black_player_id===me.id?'b':null;
  if (!color) return NextResponse.json({error:'شما بازیکن این بازی نیستید.'},{status:403});
  if (g.active_color !== color) return NextResponse.json({error:'نوبت شما نیست.'},{status:409});
  const now=Date.now();
  const elapsed=Math.max(0,now-new Date(g.last_tick_at).getTime());
  const clockField=color==='w'?'white_ms':'black_ms';
  const remaining=Math.max(0,Number(g[clockField])-elapsed);
  if (remaining<=0) {
    const result=color==='w'?'0-1':'1-0';
    const {data:ended}=await supabaseAdmin.from('online_games').update({[clockField]:0,status:'finished',result,finish_reason:'timeout',finished_at:new Date().toISOString(),last_tick_at:null}).eq('id',g.id).eq('status','playing').select('*').maybeSingle();
    if(ended) await applyGamePoints(ended);
    return NextResponse.json({error:'زمان شما تمام شد.'},{status:409});
  }
  try {
    const chess=new Chess(g.fen);
    const move=chess.move({from:String(body.from),to:String(body.to),promotion:body.promotion || 'q'});
    if(!move) return NextResponse.json({error:'حرکت قانونی نیست.'},{status:400});
    const nextColor=chess.turn();
    const increment=Number((await supabaseAdmin.from('online_tournaments').select('increment_seconds').eq('id',params.id).single()).data?.increment_seconds||0)*1000;
    const updatedClock=remaining+increment;
    const nextWhite=color==='w'?updatedClock:Number(g.white_ms);
    const nextBlack=color==='b'?updatedClock:Number(g.black_ms);
    let result:string|null=null, reason:string|null=null;
    if(chess.isCheckmate()){result=color==='w'?'1-0':'0-1';reason='checkmate';}
    else if(chess.isDraw()){result='1/2-1/2';reason=chess.isStalemate()?'stalemate':'draw';}
    const sanMoves=[...(g.moves||[]),{san:move.san,from:move.from,to:move.to,color:move.color,fen:chess.fen(),at:new Date().toISOString()}];
    const pgn=chess.pgn();
    const patch:any={fen:chess.fen(),moves:sanMoves,pgn,white_ms:nextWhite,black_ms:nextBlack,active_color:nextColor,last_tick_at:result?null:new Date().toISOString(),status:result?'finished':'playing',result,finish_reason:reason,finished_at:result?new Date().toISOString():null,draw_offer_by:null,updated_at:new Date().toISOString()};
    const {data:saved,error}=await supabaseAdmin.from('online_games').update(patch).eq('id',g.id).eq('status','playing').eq('active_color',color).select('*').maybeSingle();
    if(error || !saved) return NextResponse.json({error:'بازی هم‌زمان تغییر کرده؛ صفحه را تازه کن.'},{status:409});
    if(result) await applyGamePoints(saved);
    return NextResponse.json({game:saved});
  } catch {
    return NextResponse.json({error:'حرکت نامعتبر است.'},{status:400});
  }
}

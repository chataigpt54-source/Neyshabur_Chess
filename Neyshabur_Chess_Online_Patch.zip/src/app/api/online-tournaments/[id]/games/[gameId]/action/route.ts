import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase-admin';
import { currentOnlinePlayer, isFinishedTimeout, applyGamePoints } from '@/lib/online-chess';

export async function POST(req:NextRequest,{params}:{params:{id:string;gameId:string}}) {
  const me=await currentOnlinePlayer(params.id);
  if(!me) return NextResponse.json({error:'ابتدا وارد مسابقه شو.'},{status:401});
  let body:any;try{body=await req.json()}catch{return NextResponse.json({error:'درخواست نامعتبر است.'},{status:400})}
  const action=body.action;
  const {data:raw}=await supabaseAdmin.from('online_games').select('*').eq('id',params.gameId).eq('tournament_id',params.id).maybeSingle();
  if(!raw)return NextResponse.json({error:'بازی پیدا نشد.'},{status:404});
  const g:any=await isFinishedTimeout(raw);
  if(![g.white_player_id,g.black_player_id].includes(me.id))return NextResponse.json({error:'شما بازیکن این بازی نیستید.'},{status:403});
  if(g.status!=='playing')return NextResponse.json({error:'بازی تمام شده است.'},{status:409});
  if(action==='resign'){
    const result=g.white_player_id===me.id?'0-1':'1-0';
    const {data:ended}=await supabaseAdmin.from('online_games').update({status:'finished',result,finish_reason:'resignation',finished_at:new Date().toISOString(),last_tick_at:null,draw_offer_by:null}).eq('id',g.id).eq('status','playing').select('*').maybeSingle();
    if(ended)await applyGamePoints(ended);
    return NextResponse.json({game:ended});
  }
  if(action==='offer-draw'){
    await supabaseAdmin.from('online_games').update({draw_offer_by:me.id}).eq('id',g.id).eq('status','playing');
    return NextResponse.json({ok:true});
  }
  if(action==='reject-draw'){
    await supabaseAdmin.from('online_games').update({draw_offer_by:null}).eq('id',g.id).eq('status','playing');
    return NextResponse.json({ok:true});
  }
  if(action==='accept-draw'){
    if(!g.draw_offer_by || g.draw_offer_by===me.id)return NextResponse.json({error:'پیشنهاد مساوی از حریف ثبت نشده است.'},{status:409});
    const {data:ended}=await supabaseAdmin.from('online_games').update({status:'finished',result:'1/2-1/2',finish_reason:'agreement',finished_at:new Date().toISOString(),last_tick_at:null,draw_offer_by:null}).eq('id',g.id).eq('status','playing').select('*').maybeSingle();
    if(ended)await applyGamePoints(ended);
    return NextResponse.json({game:ended});
  }
  return NextResponse.json({error:'عملیات ناشناخته است.'},{status:400});
}

import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase-admin';
import { currentOnlinePlayer, isFinishedTimeout } from '@/lib/online-chess';

export async function GET(_req:Request,{params}:{params:{id:string}}) {
  const me = await currentOnlinePlayer(params.id);
  const {data:t} = await supabaseAdmin.from('online_tournaments').select('id,status,format,start_at,time_minutes,time_seconds,increment_seconds,rounds,duration_minutes').eq('id',params.id).maybeSingle();
  if (!t) return NextResponse.json({error:'مسابقه پیدا نشد.'},{status:404});
  // Auto-finalize Arena once its configured duration has elapsed.
  if (t.format === 'arena' && t.status === 'running' &&
      Date.now() >= new Date(t.start_at).getTime() + Number(t.duration_minutes) * 60000) {
    const {data:ps} = await supabaseAdmin.from('online_players').select('id,display_name,points,bye_count,joined_at').eq('tournament_id',params.id);
    const {data:gs} = await supabaseAdmin.from('online_games').select('white_player_id,black_player_id,result,status').eq('tournament_id',params.id);
    const all:any[] = ps || [], played:any[] = gs || [];
    const standings = all.map((p:any) => {
      const opponents = played.filter(g => g.white_player_id===p.id || g.black_player_id===p.id)
        .map(g => all.find(o => o.id === (g.white_player_id===p.id ? g.black_player_id : g.white_player_id))).filter(Boolean);
      const buchholz = opponents.reduce((sum:number,o:any)=>sum+Number(o.points||0),0);
      const mine = played.filter(g => (g.white_player_id===p.id || g.black_player_id===p.id) && g.status==='finished');
      const wins = mine.filter(g => (g.result==='1-0'&&g.white_player_id===p.id)||(g.result==='0-1'&&g.black_player_id===p.id)).length;
      return {player_id:p.id,name:p.display_name,points:Number(p.points||0),buchholz,games_played:mine.length,wins,bye_count:p.bye_count||0};
    }).sort((a:any,b:any)=>b.points-a.points||b.buchholz-a.buchholz||b.wins-a.wins||a.name.localeCompare(b.name,'fa'));
    const ranked=standings.map((p:any,i:number)=>({...p,rank:i+1}));
    await supabaseAdmin.from('online_tournaments').update({status:'finished',standings:ranked,top_three:ranked.slice(0,3).map((p:any)=>({rank:p.rank,name:p.name,points:p.points})),finished_at:new Date().toISOString()}).eq('id',params.id).eq('status','running');
    t.status='finished';
  }
  const {data:players} = await supabaseAdmin.from('online_players').select('id,display_name,points,bye_count').eq('tournament_id',params.id).order('points',{ascending:false});
  const {data:raw} = await supabaseAdmin.from('online_games').select('*').eq('tournament_id',params.id).order('round_number',{ascending:false}).limit(100);
  const games:any[]=[];
  for (const g of raw||[]) games.push(await isFinishedTimeout(g));
  const safeGames = games.map(g=>({...g, moves: g.moves || [], pgn:g.pgn || ''}));
  return NextResponse.json({tournament:t, players:players||[], games:safeGames, me:me?{id:me.id,display_name:me.display_name}:null});
}

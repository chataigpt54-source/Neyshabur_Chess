import { NextResponse } from 'next/server';
import { isAdminAuthenticated } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase-admin';

export async function POST(_req:Request,{params}:{params:{id:string}}) {
 if(!(await isAdminAuthenticated()))return NextResponse.json({error:'دسترسی غیرمجاز است.'},{status:401});
 const {data:t}=await supabaseAdmin.from('online_tournaments').select('*').eq('id',params.id).maybeSingle();
 if(!t)return NextResponse.json({error:'مسابقه پیدا نشد.'},{status:404});
 const {data:players}=await supabaseAdmin.from('online_players').select('id,display_name,points,bye_count,joined_at').eq('tournament_id',params.id);
 const {data:games}=await supabaseAdmin.from('online_games').select('white_player_id,black_player_id,result,status,round_number').eq('tournament_id',params.id);
 const all=players||[], gs=games||[];
 const standings=all.map((p:any)=>{
   const opponents=gs.filter((g:any)=>g.white_player_id===p.id||g.black_player_id===p.id).map((g:any)=>all.find((x:any)=>x.id===(g.white_player_id===p.id?g.black_player_id:g.white_player_id))).filter(Boolean);
   const buchholz=opponents.reduce((s:number,o:any)=>s+Number(o.points||0),0);
   const played=gs.filter((g:any)=>(g.white_player_id===p.id||g.black_player_id===p.id)&&g.status==='finished');
   const wins=played.filter((g:any)=>(g.result==='1-0'&&g.white_player_id===p.id)||(g.result==='0-1'&&g.black_player_id===p.id)).length;
   return {player_id:p.id,name:p.display_name,points:Number(p.points||0),buchholz,games_played:played.length,wins,bye_count:p.bye_count||0,joined_at:p.joined_at};
 }).sort((a:any,b:any)=>b.points-a.points||b.buchholz-a.buchholz||b.wins-a.wins||a.name.localeCompare(b.name,'fa'));
 const ranked=standings.map((p:any,i:number)=>({...p,rank:i+1}));
 const top_three=ranked.slice(0,3).map((p:any)=>({rank:p.rank,name:p.name,points:p.points}));
 const {data,error}=await supabaseAdmin.from('online_tournaments').update({status:'finished',top_three,standings:ranked,updated_at:new Date().toISOString()}).eq('id',params.id).select().single();
 if(error)return NextResponse.json({error:'ذخیره نتایج نهایی ناموفق بود.'},{status:500});
 return NextResponse.json({tournament:data,standings:ranked,top_three});
}

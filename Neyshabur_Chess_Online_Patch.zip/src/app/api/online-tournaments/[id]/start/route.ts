import { NextResponse } from 'next/server';
import { isAdminAuthenticated } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase-admin';
import { createRound } from '@/lib/online-chess';

export async function POST(_req: Request,{params}:{params:{id:string}}) {
  if (!(await isAdminAuthenticated())) return NextResponse.json({error:'دسترسی غیرمجاز است.'},{status:401});
  const {data:t} = await supabaseAdmin.from('online_tournaments').select('*').eq('id',params.id).maybeSingle();
  if (!t) return NextResponse.json({error:'مسابقه پیدا نشد.'},{status:404});
  if (t.status === 'finished' || t.status === 'cancelled') return NextResponse.json({error:'این مسابقه قابل شروع نیست.'},{status:409});
  await supabaseAdmin.from('online_tournaments').update({status:'running'}).eq('id',params.id);
  try {
    const result = await createRound(params.id);
    return NextResponse.json({ok:true,...result});
  } catch(e:any) {
    return NextResponse.json({error:e?.message || 'شروع مسابقه ناموفق بود.'},{status:400});
  }
}

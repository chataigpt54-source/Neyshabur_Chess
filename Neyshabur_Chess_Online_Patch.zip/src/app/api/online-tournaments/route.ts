import { NextRequest, NextResponse } from 'next/server';
import { isAdminAuthenticated } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase-admin';

export async function GET() {
 const {data,error}=await supabaseAdmin.from('online_tournaments').select('id,title,description,format,start_at,status,time_minutes,time_seconds,increment_seconds,rounds,duration_minutes,capacity,created_at').order('start_at',{ascending:false});
 if(error)return NextResponse.json({error:'دریافت مسابقات ناموفق بود.'},{status:500});
 return NextResponse.json({tournaments:data||[]});
}
export async function POST(req:NextRequest) {
 if(!(await isAdminAuthenticated()))return NextResponse.json({error:'دسترسی غیرمجاز است.'},{status:401});
 let b:any;try{b=await req.json()}catch{return NextResponse.json({error:'JSON نامعتبر است.'},{status:400})}
 const title=typeof b.title==='string'?b.title.trim():'';
 const format=b.format;
 const start=new Date(b.start_at);
 const timeMinutes=Number(b.time_minutes), timeSeconds=Number(b.time_seconds||0), increment=Number(b.increment_seconds||0);
 const rounds=Number(b.rounds||7), duration=Number(b.duration_minutes||60), capacity=Number(b.capacity||100);
 if(!title||title.length>160||!['swiss','arena'].includes(format)||!Number.isFinite(start.getTime()))return NextResponse.json({error:'عنوان، نوع یا تاریخ معتبر نیست.'},{status:400});
 if(!Number.isInteger(timeMinutes)||timeMinutes<0||timeMinutes>10080||!Number.isInteger(timeSeconds)||timeSeconds<0||timeSeconds>59||timeMinutes*60+timeSeconds<1||!Number.isInteger(increment)||increment<0||increment>3600||!Number.isInteger(capacity)||capacity<2||capacity>2000)return NextResponse.json({error:'تنظیمات زمان یا ظرفیت معتبر نیست.'},{status:400});
 if(format==='swiss'&&(!Number.isInteger(rounds)||rounds<1||rounds>50))return NextResponse.json({error:'تعداد دورها باید بین ۱ تا ۵۰ باشد.'},{status:400});
 if(format==='arena'&&(!Number.isInteger(duration)||duration<1||duration>10080))return NextResponse.json({error:'مدت آرنا معتبر نیست.'},{status:400});
 const {data,error}=await supabaseAdmin.from('online_tournaments').insert({title,description:String(b.description||'').slice(0,10000),format,start_at:start.toISOString(),status:'scheduled',time_minutes:timeMinutes,time_seconds:timeSeconds,increment_seconds:increment,rounds,duration_minutes:duration,capacity}).select().single();
 if(error)return NextResponse.json({error:'ذخیره مسابقه ناموفق بود.'},{status:500});
 return NextResponse.json({tournament:data},{status:201});
}

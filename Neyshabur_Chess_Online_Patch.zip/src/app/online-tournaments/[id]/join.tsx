'use client';
import {useState} from 'react';
import {useRouter} from 'next/navigation';
export default function JoinTournament({id}:{id:string}){
 const [name,setName]=useState('');const [error,setError]=useState('');const [busy,setBusy]=useState(false);const router=useRouter();
 async function join(e:React.FormEvent){e.preventDefault();setBusy(true);setError('');try{const r=await fetch(`/api/online-tournaments/${id}/join`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({display_name:name})});const d=await r.json();if(!r.ok){setError(d.error||'ثبت‌نام ناموفق بود');return}router.refresh()}catch{setError('خطا در اتصال به سرور')}finally{setBusy(false)}}
 return <form onSubmit={join} className="mt-6 flex flex-wrap items-end gap-3 rounded-2xl bg-emerald-50 p-4"><label className="flex-1 space-y-2"><span className="block font-bold">نام نمایشی (بدون ساخت حساب)</span><input required minLength={2} maxLength={32} value={name} onChange={e=>setName(e.target.value)} className="w-full rounded-xl border p-3" placeholder="نام فارسی یا انگلیسی"/></label><button disabled={busy} className="rounded-xl bg-emerald-700 px-5 py-3 font-bold text-white">{busy?'در حال ثبت‌نام...':'شرکت در مسابقه'}</button>{error&&<p role="alert" className="w-full text-red-700">{error}</p>}</form>
}

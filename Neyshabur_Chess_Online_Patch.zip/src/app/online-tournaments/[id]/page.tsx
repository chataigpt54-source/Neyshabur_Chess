import {notFound} from 'next/navigation';
import Link from 'next/link';
import JoinTournament from './join';
export const dynamic='force-dynamic';
export default async function TournamentPage({params}:{params:{id:string}}){
 const {supabaseAdmin}=await import('@/lib/supabase-admin');
 const {data:t}=await supabaseAdmin.from('online_tournaments').select('*').eq('id',params.id).maybeSingle();
 if(!t)notFound();
 const {data:players}=await supabaseAdmin.from('online_players').select('id,display_name,points').eq('tournament_id',params.id).order('points',{ascending:false});
 const {data:games}=await supabaseAdmin.from('online_games').select('id,round_number,white_name,black_name,status,result').eq('tournament_id',params.id).order('round_number',{ascending:false}).limit(100);
 return <main dir="rtl" className="mx-auto max-w-5xl px-4 py-10"><Link href="/online-tournaments" className="text-emerald-800 underline">بازگشت</Link><h1 className="mt-5 text-3xl font-black">{t.title}</h1><p className="mt-3 whitespace-pre-wrap">{t.description}</p>
 <p className="mt-3 text-sm">زمان {t.time_minutes}:{String(t.time_seconds).padStart(2,'0')} + {t.increment_seconds} ثانیه فیشر · {t.format==='swiss'?`${t.rounds} دور سوئیسی`:`آرنا ${t.duration_minutes} دقیقه`}</p>
 {t.status==='scheduled'&&<JoinTournament id={t.id} />}
 <div className="mt-8 grid gap-6 md:grid-cols-2"><section className="rounded-2xl border p-5"><h2 className="text-xl font-bold">شرکت‌کنندگان</h2>{(players||[]).map((p:any)=><p className="mt-2" key={p.id}>{p.display_name} — {p.points} امتیاز</p>)}</section>
 <section className="rounded-2xl border p-5"><h2 className="text-xl font-bold">بازی‌ها</h2>{(games||[]).map((g:any)=><div className="mt-3 border-b pb-2" key={g.id}><p>دور {g.round_number}: {g.white_name||'سفید'} — {g.black_name||'سیاه'}</p><p className="text-sm text-slate-500">{g.status==='finished'?`نتیجه ${g.result}`:'در انتظار / در حال بازی'}</p>{g.status!=='finished'&&<Link className="text-emerald-800 underline" href={`/online-tournaments/${t.id}/game/${g.id}`}>باز کردن صفحه بازی</Link>}</div>)}</section></div>
 {t.status==='finished'&&<section className="mt-6 rounded-2xl bg-amber-50 p-5"><h2 className="text-xl font-black">سه نفر برتر</h2>{(t.top_three||[]).map((p:any)=><p key={p.rank}>{p.rank}. {p.name} — {p.points}</p>)}</section>}</main>
}

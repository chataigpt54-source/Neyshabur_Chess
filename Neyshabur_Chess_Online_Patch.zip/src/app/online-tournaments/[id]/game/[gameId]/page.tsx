import {notFound} from 'next/navigation';
import GameClient from './game-client';
export const dynamic='force-dynamic';
export default async function GamePage({params}:{params:{id:string;gameId:string}}){
 const {supabaseAdmin}=await import('@/lib/supabase-admin');
 const {data:g}=await supabaseAdmin.from('online_games').select('id,tournament_id').eq('id',params.gameId).eq('tournament_id',params.id).maybeSingle();
 if(!g)notFound();
 return <GameClient tournamentId={params.id} gameId={params.gameId}/>;
}

'use client';
import {useCallback,useEffect,useState} from 'react';
import {Chess} from 'chess.js';
import Link from 'next/link';

const files='abcdefgh';
function clock(ms:number){const s=Math.max(0,Math.ceil(ms/1000));return `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`}
export default function GameClient({tournamentId,gameId}:{tournamentId:string;gameId:string}){
 const [data,setData]=useState<any>(null);const [selected,setSelected]=useState<string|null>(null);const [busy,setBusy]=useState(false);const [err,setErr]=useState('');const [tick,setTick]=useState(Date.now());
 const refresh=useCallback(async()=>{try{const r=await fetch(`/api/online-tournaments/${tournamentId}/games`,{cache:'no-store'});const d=await r.json();if(r.ok)setData(d);else setErr(d.error||'خطا')}catch{}},[tournamentId]);
 useEffect(()=>{refresh();const p=setInterval(refresh,1500);const t=setInterval(()=>setTick(Date.now()),250);return()=>{clearInterval(p);clearInterval(t)}},[refresh]);
 const game=data?.games?.find((g:any)=>g.id===gameId);
 const me=data?.me;const color=game&&me?(game.white_player_id===me.id?'w':game.black_player_id===me.id?'b':null):null;
 let chess:Chess|null=null;try{if(game)chess=new Chess(game.fen)}catch{}
 async function move(from:string,to:string){if(!game||!color||busy)return;setBusy(true);setErr('');try{const r=await fetch(`/api/online-tournaments/${tournamentId}/games/${gameId}/move`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({from,to,promotion:'q'})});const d=await r.json();if(!r.ok)setErr(d.error||'حرکت انجام نشد');await refresh();}catch{setErr('ارتباط با سرور قطع شد')}finally{setBusy(false);setSelected(null)}}
 async function action(action:string){setBusy(true);setErr('');try{const r=await fetch(`/api/online-tournaments/${tournamentId}/games/${gameId}/action`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action})});const d=await r.json();if(!r.ok)setErr(d.error||'عملیات انجام نشد');await refresh()}catch{setErr('ارتباط با سرور قطع شد')}finally{setBusy(false)}}
 async function copyPGN(){try{await navigator.clipboard.writeText(game?.pgn||'');setErr('PGN کپی شد.')}catch{setErr('کپی PGN ممکن نشد.')}}
 if(!data||!game)return <main dir="rtl" className="p-8">در حال بارگذاری بازی...</main>;
 const elapsed=game.status==='playing'&&game.last_tick_at?Math.max(0,tick-new Date(game.last_tick_at).getTime()):0;
 const wms=Math.max(0,Number(game.white_ms)-(game.active_color==='w'?elapsed:0));
 const bms=Math.max(0,Number(game.black_ms)-(game.active_color==='b'?elapsed:0));
 const boardColor=color==='b'?'b':'w';
 const squares:string[]=[];
 for(let row=0;row<8;row++)for(let col=0;col<8;col++){const r=boardColor==='w'?row:7-row,c=boardColor==='w'?col:7-col;squares.push(files[c]+(8-r))}
 const glyph:any={k:'♚',q:'♛',r:'♜',b:'♝',n:'♞',p:'♟'};
 const pieces=chess?.board()||[];
 function pieceAt(sq:string){const c=new Chess(game.fen);const p=c.get(sq as any);if(!p)return '';return p.color==='w'?glyph[p.type].replace('♚','♔').replace('♛','♕').replace('♜','♖').replace('♝','♗').replace('♞','♘').replace('♟','♙'):glyph[p.type]}
 return <main dir="rtl" className="mx-auto max-w-4xl px-3 py-6"><Link href={`/online-tournaments/${tournamentId}`} className="text-emerald-800 underline">بازگشت به مسابقه</Link><h1 className="my-4 text-2xl font-black">{game.white_name} — {game.black_name}</h1>
 <div className="mb-3 grid grid-cols-2 gap-3"><div className={`rounded-xl p-4 text-center ${game.active_color==='b'?'bg-slate-900 text-white':'bg-slate-100'}`}><div>{game.black_name} · سیاه</div><div className="text-3xl font-mono font-black">{clock(bms)}</div></div><div className={`rounded-xl p-4 text-center ${game.active_color==='w'?'bg-slate-900 text-white':'bg-slate-100'}`}><div>{game.white_name} · سفید</div><div className="text-3xl font-mono font-black">{clock(wms)}</div></div></div>
 <div className="mx-auto grid aspect-square w-full max-w-[560px] grid-cols-8 overflow-hidden rounded-lg border-4 border-emerald-950">{squares.map((sq,i)=>{const p=pieceAt(sq);const light=(Number(sq[1])+files.indexOf(sq[0]))%2===0;return <button key={sq} aria-label={sq} disabled={!color||game.status!=='playing'||busy} onClick={()=>{if(!selected){if(p)setSelected(sq);return}if(selected===sq){setSelected(null);return}void move(selected,sq)}} className={`relative flex items-center justify-center text-[clamp(1.7rem,7vw,3.7rem)] leading-none ${light?'bg-[#eeeed2]':'bg-[#769656]'} ${selected===sq?'ring-4 ring-inset ring-yellow-400':''}`}>{p}{i%8===0&&<span className="absolute left-1 top-0 text-[10px] opacity-70">{sq[1]}</span>}{i>=56&&<span className="absolute bottom-0 right-1 text-[10px] opacity-70">{sq[0]}</span>}</button>})}</div>
 <p className="mt-3 text-center text-sm text-slate-600">{color?`شما با مهره ${color==='w'?'سفید':'سیاه'} بازی می‌کنید.`:'برای بازی باید با نام خود در مسابقه ثبت‌نام کرده باشید.'} · وضعیت: {game.status==='finished'?`پایان یافته (${game.result})`:game.status}</p>
 {game.draw_offer_by&&game.draw_offer_by!==me?.id&&game.status==='playing'&&<div className="mt-4 rounded-xl bg-amber-50 p-4">حریف پیشنهاد مساوی داده است. <button onClick={()=>action('accept-draw')} className="mx-2 rounded bg-emerald-700 px-3 py-2 text-white">قبول مساوی</button><button onClick={()=>action('reject-draw')} className="rounded bg-slate-700 px-3 py-2 text-white">رد</button></div>}
 {color&&game.status==='playing'&&<div className="mt-4 flex flex-wrap justify-center gap-2"><button disabled={busy} onClick={()=>action('offer-draw')} className="rounded-lg border px-4 py-2">پیشنهاد مساوی</button><button disabled={busy} onClick={()=>action('resign')} className="rounded-lg border border-red-300 px-4 py-2 text-red-700">تسلیم</button></div>}
 <div className="mt-4 flex justify-center gap-3"><button onClick={copyPGN} className="rounded-lg bg-slate-800 px-4 py-2 text-white">کپی PGN</button><button onClick={refresh} className="rounded-lg border px-4 py-2">به‌روزرسانی</button></div>
 {err&&<p role="status" className="mt-3 text-center text-sm">{err}</p>}
 <section className="mt-6 rounded-xl bg-slate-50 p-4"><h2 className="font-bold">حرکت‌ها</h2><p className="mt-2 break-words">{(game.moves||[]).map((m:any,i:number)=>`${Math.floor(i/2)+1}${i%2===0?'.':'...'} ${m.san}`).join(' ')||'هنوز حرکتی ثبت نشده است.'}</p></section></main>
}

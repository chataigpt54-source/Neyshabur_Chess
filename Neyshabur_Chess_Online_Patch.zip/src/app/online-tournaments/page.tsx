import Link from 'next/link';
export const dynamic='force-dynamic';
export default async function OnlineTournamentsPage(){
 const {supabaseAdmin}=await import('@/lib/supabase-admin');
 const {data}=await supabaseAdmin.from('online_tournaments').select('*').order('start_at',{ascending:false});
 const labels:any={scheduled:'زمان‌بندی‌شده',registration:'ثبت‌نام',running:'در حال اجرا',finished:'پایان‌یافته',cancelled:'لغوشده'};
 return <main dir="rtl" className="mx-auto max-w-6xl px-4 py-10"><h1 className="text-3xl font-black">مسابقات آنلاین شطرنج</h1><p className="mt-2 text-slate-600">مسابقات و آرشیو هیأت شطرنج نیشابور</p>
 <div className="mt-8 grid gap-5 md:grid-cols-2">{(data||[]).map((t:any)=><article key={t.id} className="rounded-2xl border bg-white p-5 shadow-sm">
 <div className="flex justify-between"><span className="rounded-full bg-emerald-50 px-3 py-1 text-sm">{labels[t.status]||t.status}</span><span>{t.format==='swiss'?'سوئیسی':'آرنا'}</span></div>
 <h2 className="mt-4 text-xl font-black">{t.title}</h2><p className="mt-2 whitespace-pre-wrap text-slate-600">{t.description}</p>
 <p className="mt-3 text-sm">شروع: {new Date(t.start_at).toLocaleString('fa-IR',{timeZone:'Asia/Tehran'})}</p>
 <p className="mt-1 text-sm">زمان: {t.time_minutes}:{String(t.time_seconds).padStart(2,'0')} + {t.increment_seconds} ثانیه فیشر</p>
 {t.status==='finished'&&Array.isArray(t.top_three)&&t.top_three.length>0&&<div className="mt-4 rounded-xl bg-amber-50 p-3"><b>سه نفر برتر</b>{t.top_three.map((p:any)=><p key={p.rank}>{p.rank}. {p.name} — {p.points}</p>)}</div>}
 <Link className="mt-4 inline-flex rounded-xl bg-emerald-700 px-4 py-3 font-bold text-white" href={`/online-tournaments/${t.id}`}>ورود / مشاهده</Link></article>)}</div>
 {(data||[]).length===0&&<p className="mt-8 rounded-xl bg-slate-50 p-6">هنوز مسابقه‌ای ثبت نشده است.</p>}</main>
}

# راه‌اندازی مسابقات آنلاین

## 1) دیتابیس
فایل `supabase-online-chess.sql` را در Supabase SQL Editor اجرا کنید. این فایل فقط جداول `online_*` را می‌سازد و به جداول مسابقات حضوری دست نمی‌زند.

## 2) کلید سرور
در `.env.local` (و Environment Variables در Vercel) لازم است:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` (برای بخش‌های قبلی پروژه)
- `SUPABASE_SERVICE_ROLE_KEY` (فقط سمت سرور؛ هرگز `NEXT_PUBLIC_` نگذارید)

## 3) نصب
```bash
npm install
npm run dev
```
وابستگی `chess.js` به `package.json` اضافه شده است.

## 4) مسیرها
- `/online-tournaments`: فهرست و آرشیو
- `/online-tournaments/[id]`: جزئیات، ثبت‌نام و بازی‌ها
- `/online-tournaments/[id]/game/[gameId]`: صفحه بازی
- `/admin/online-tournaments`: ساخت مسابقه، شروع دور و ثبت جدول نهایی
- `/api/online-tournaments`: فهرست و ایجاد مسابقه
- `/api/online-tournaments/[id]/join`: ثبت‌نام با نام نمایشی و کوکی امن
- `/api/online-tournaments/[id]/start`: شروع مسابقه یا ساخت دور بعد
- `/api/online-tournaments/[id]/finalize`: ثبت جدول نهایی
- `/api/online-tournaments/[id]/games`: دریافت بازی‌ها و ساعت‌ها
- `/api/online-tournaments/[id]/games/[gameId]/move`: اعتبارسنجی حرکت سمت سرور با chess.js
- `/api/online-tournaments/[id]/games/[gameId]/action`: پیشنهاد/پذیرش مساوی و تسلیم

## توجه فنی مهم
این نسخه یک پیاده‌سازی پایه قابل نصب است، اما پیش از استفاده در مسابقه رسمی باید تست هم‌زمانی روی حرکت‌ها/ساعت‌ها و تست امنیتی انجام شود. به‌خصوص، به‌روزرسانی ساعت و امتیاز در چند درخواست هم‌زمان هنوز تراکنش اتمیک PostgreSQL نیست. شروع دور بعد سوئیسی از پنل مدیر انجام می‌شود و پایان آرنا به job/cron سمت سرور نیاز دارد؛ پایان مسابقه از پنل مدیر قابل ثبت است. برای پایداری در سطح مسابقات رسمی باید این عملیات‌ها به PostgreSQL RPC/transaction منتقل شوند.

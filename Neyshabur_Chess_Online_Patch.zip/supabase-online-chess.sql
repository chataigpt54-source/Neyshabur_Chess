-- Online chess tournaments for Neyshabur Chess Board
-- Run in Supabase SQL Editor after the existing schema.
create extension if not exists pgcrypto;

create table if not exists public.online_tournaments (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  format text not null check (format in ('swiss','arena')),
  start_at timestamptz not null,
  status text not null default 'scheduled' check (status in ('scheduled','registration','running','finished','cancelled')),
  time_minutes integer not null default 5 check (time_minutes >= 0),
  time_seconds integer not null default 0 check (time_seconds between 0 and 59),
  increment_seconds integer not null default 0 check (increment_seconds >= 0),
  rounds integer not null default 7 check (rounds between 1 and 50),
  duration_minutes integer not null default 60 check (duration_minutes >= 1),
  capacity integer not null default 100 check (capacity between 2 and 2000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.online_players (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.online_tournaments(id) on delete cascade,
  display_name text not null,
  token_hash text not null,
  points numeric(5,1) not null default 0,
  bye_count integer not null default 0,
  joined_at timestamptz not null default now(),
  unique(tournament_id, token_hash)
);

create table if not exists public.online_games (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.online_tournaments(id) on delete cascade,
  round_number integer not null default 1,
  white_player_id uuid references public.online_players(id) on delete set null,
  black_player_id uuid references public.online_players(id) on delete set null,
  status text not null default 'waiting' check (status in ('waiting','playing','finished')),
  fen text not null default 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
  pgn text not null default '',
  moves jsonb not null default '[]'::jsonb,
  white_ms bigint not null default 300000,
  black_ms bigint not null default 300000,
  active_color text not null default 'w' check (active_color in ('w','b')),
  last_tick_at timestamptz,
  draw_offer_by uuid references public.online_players(id) on delete set null,
  result text,
  finish_reason text,
  started_at timestamptz,
  finished_at timestamptz,
  created_at timestamptz not null default now(),
  unique(tournament_id, round_number, white_player_id),
  unique(tournament_id, round_number, black_player_id)
);

create index if not exists idx_online_tournaments_start on public.online_tournaments(start_at);
create index if not exists idx_online_players_tournament on public.online_players(tournament_id);
create index if not exists idx_online_games_tournament_round on public.online_games(tournament_id, round_number);

alter table public.online_tournaments enable row level security;
alter table public.online_players enable row level security;
alter table public.online_games enable row level security;

-- No public table policies: all reads/writes go through Next.js API routes.
-- Server routes use SUPABASE_SERVICE_ROLE_KEY. Never expose that key to browsers.

-- Final archive fields used by the results page.
alter table public.online_tournaments
  add column if not exists standings jsonb not null default '[]'::jsonb,
  add column if not exists top_three jsonb not null default '[]'::jsonb,
  add column if not exists finished_at timestamptz;
alter table public.online_games
  add column if not exists points_applied boolean not null default false,
  add column if not exists updated_at timestamptz not null default now();

alter table public.online_games add column if not exists white_name text not null default 'سفید', add column if not exists black_name text not null default 'سیاه';
